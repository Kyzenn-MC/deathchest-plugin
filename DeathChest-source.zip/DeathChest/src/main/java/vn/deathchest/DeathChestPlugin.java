package vn.deathchest;

import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class DeathChestPlugin extends JavaPlugin implements CommandExecutor, TabCompleter {

    private record Warmup(BukkitTask task) {}

    private ChestManager manager;
    private final MiniMessage mm = MiniMessage.miniMessage();
    private final Set<UUID> voidPending = ConcurrentHashMap.newKeySet();
    private final Map<UUID, Warmup> warmups = new HashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        manager = new ChestManager(this);
        manager.start();
        getServer().getPluginManager().registerEvents(new DeathListener(this, manager), this);

        PluginCommand back = getCommand("back");
        if (back != null) {
            back.setExecutor(this);
            back.setTabCompleter(this);
        }
        PluginCommand admin = getCommand("deathchest");
        if (admin != null) {
            admin.setExecutor(this);
            admin.setTabCompleter(this);
        }
    }

    @Override
    public void onDisable() {
        for (Warmup w : warmups.values()) w.task().cancel();
        warmups.clear();
        if (manager != null) manager.stop();
    }

    // ----------------------------------------------------------- messages

    public void msg(CommandSender to, String key, TagResolver... resolvers) {
        String raw = getConfig().getString("messages." + key, "");
        if (raw.isEmpty()) return;
        String prefix = getConfig().getString("messages.prefix", "");
        to.sendMessage(mm.deserialize(prefix + raw, resolvers));
    }

    // ----------------------------------------------------------- commands

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (cmd.getName().equalsIgnoreCase("deathchest")) {
            if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
                if (!sender.hasPermission("deathchest.admin")) {
                    msg(sender, "no-perm");
                    return true;
                }
                reloadConfig();
                manager.refreshAllDisplays();
                msg(sender, "reloaded");
                return true;
            }
            sender.sendMessage("/deathchest reload");
            return true;
        }

        if (!(sender instanceof Player p)) {
            msg(sender, "players-only");
            return true;
        }
        handleBack(p);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        if (cmd.getName().equalsIgnoreCase("deathchest") && args.length == 1) return List.of("reload");
        return List.of();
    }

    // --------------------------------------------------------------- /back

    /**
     * /back CHỈ đưa người chơi tới rương tử vong còn tồn tại của chính họ. Plugin không hề lưu
     * "vị trí trước khi tp", nên gọi /back lần 2 không thể đưa người chơi quay lại chỗ cũ.
     * Mặc định mỗi rương chỉ dùng /back được 1 lần.
     */
    private void handleBack(Player p) {
        if (!getConfig().getBoolean("back.enabled", true)) {
            msg(p, "back-none");
            return;
        }
        DeathChest r = manager.latestFor(p.getUniqueId(), getConfig().getBoolean("back.one-use-per-chest", true));
        if (r == null) {
            msg(p, "back-none");
            return;
        }
        if (warmups.containsKey(p.getUniqueId())) {
            msg(p, "back-already");
            return;
        }
        int warm = getConfig().getInt("back.warmup-seconds", 3);
        if (warm <= 0) {
            doBack(p, r);
            return;
        }
        msg(p, "back-warmup", Placeholder.unparsed("seconds", String.valueOf(warm)));
        BukkitTask t = Bukkit.getScheduler().runTaskLater(this, () -> {
            warmups.remove(p.getUniqueId());
            doBack(p, r);
        }, warm * 20L);
        warmups.put(p.getUniqueId(), new Warmup(t));
    }

    public void cancelWarmup(Player p, boolean notify) {
        Warmup w = warmups.remove(p.getUniqueId());
        if (w == null) return;
        w.task().cancel();
        if (notify) msg(p, "back-cancelled");
    }

    private void doBack(Player p, DeathChest r) {
        if (!p.isOnline() || p.isDead()) return;
        if (manager.get(r.id) == null) {
            msg(p, "back-none");
            return;
        }
        World w = Bukkit.getWorld(r.worldId);
        if (w == null) {
            msg(p, "back-failed");
            return;
        }
        // nạp chunk bất đồng bộ rồi mới dịch chuyển
        w.getChunkAtAsync(r.x >> 4, r.z >> 4).thenAccept(chunk ->
                Bukkit.getScheduler().runTask(this, () -> finishBack(p, r)));
    }

    private void finishBack(Player p, DeathChest r) {
        if (!p.isOnline() || p.isDead() || manager.get(r.id) == null) return;
        Location dest = manager.standLocation(r);
        if (dest == null) {
            msg(p, "back-failed");
            return;
        }
        boolean oneUse = getConfig().getBoolean("back.one-use-per-chest", true);
        if (oneUse) r.backUsed = true;
        p.teleportAsync(dest).thenAccept(ok ->
                Bukkit.getScheduler().runTask(this, () -> {
                    if (Boolean.TRUE.equals(ok)) {
                        p.setFallDistance(0);
                        msg(p, "back-done");
                        manager.save();
                    } else {
                        if (oneUse) r.backUsed = false;
                        msg(p, "back-failed");
                    }
                }));
    }

    // ---------------------------------------------------------------- void

    public void rescueFromVoid(Player p) {
        if (p.isDead() || !voidPending.add(p.getUniqueId())) return;

        World w = p.getWorld();
        String name = getConfig().getString("void-rescue.world", "");
        if (name != null && !name.isBlank()) {
            World t = Bukkit.getWorld(name);
            if (t != null) w = t;
        }
        Location spawn = w.getSpawnLocation().add(0.5, 0, 0.5);

        p.setFallDistance(0);
        p.setVelocity(new Vector(0, 0, 0));
        p.teleportAsync(spawn).whenComplete((ok, ex) ->
                Bukkit.getScheduler().runTask(this, () -> {
                    voidPending.remove(p.getUniqueId());
                    if (Boolean.TRUE.equals(ok)) {
                        p.setFallDistance(0);
                        msg(p, "void-rescued");
                    }
                }));
    }
}
