package vn.deathchest;

import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Bukkit;
import org.bukkit.block.Block;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

public final class DeathListener implements Listener {

    private final DeathChestPlugin plugin;
    private final ChestManager manager;

    public DeathListener(DeathChestPlugin plugin, ChestManager manager) {
        this.plugin = plugin;
        this.manager = manager;
    }

    // ------------------------------------------------------------ death

    @EventHandler(priority = EventPriority.HIGH)
    public void onDeath(PlayerDeathEvent e) {
        if (e.getKeepInventory()) return;
        Player p = e.getEntity();
        plugin.cancelWarmup(p, false);

        List<ItemStack> drops = new ArrayList<>();
        for (ItemStack i : e.getDrops()) {
            if (i != null && !i.getType().isAir()) drops.add(i);
        }
        if (drops.isEmpty()) return;

        e.getDrops().clear();
        DeathChest r = manager.create(p, p.getLocation(), drops);
        if (r != null) {
            plugin.msg(p, "chest-created",
                    Placeholder.unparsed("x", String.valueOf(r.x)),
                    Placeholder.unparsed("y", String.valueOf(r.y)),
                    Placeholder.unparsed("z", String.valueOf(r.z)));
        }
    }

    // ------------------------------------------------------------- void

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onVoidDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        if (e.getCause() != EntityDamageEvent.DamageCause.VOID) return;
        if (!plugin.getConfig().getBoolean("void-rescue.enabled", true)) return;
        e.setCancelled(true);
        plugin.rescueFromVoid(p);
    }

    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        Player p = e.getPlayer();
        if (e.getTo() == null) return;

        if (e.hasChangedBlock()) plugin.cancelWarmup(p, true);

        if (!plugin.getConfig().getBoolean("void-rescue.enabled", true)) return;
        int depth = plugin.getConfig().getInt("void-rescue.trigger-depth", 20);
        if (depth > 0 && e.getTo().getY() < e.getTo().getWorld().getMinHeight() - depth) {
            plugin.rescueFromVoid(p);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        plugin.cancelWarmup(e.getPlayer(), false);
    }

    // --------------------------------------------------- protect chests

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (manager.isChest(e.getBlock())) {
            e.setCancelled(true);
            plugin.msg(e.getPlayer(), "cannot-break");
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onEntityExplode(EntityExplodeEvent e) {
        e.blockList().removeIf(manager::isChest);
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent e) {
        e.blockList().removeIf(manager::isChest);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPistonExtend(BlockPistonExtendEvent e) {
        for (Block b : e.getBlocks()) {
            if (manager.isChest(b)) {
                e.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onPistonRetract(BlockPistonRetractEvent e) {
        for (Block b : e.getBlocks()) {
            if (manager.isChest(b)) {
                e.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onBurn(BlockBurnEvent e) {
        if (manager.isChest(e.getBlock())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onEntityChangeBlock(EntityChangeBlockEvent e) {
        if (manager.isChest(e.getBlock())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onHopper(InventoryMoveItemEvent e) {
        if (manager.chestOf(e.getSource()) != null || manager.chestOf(e.getDestination()) != null) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK || e.getClickedBlock() == null) return;
        DeathChest r = manager.at(e.getClickedBlock());
        if (r == null) return;
        if (!plugin.getConfig().getBoolean("chest.owner-only", false)) return;
        Player p = e.getPlayer();
        if (p.getUniqueId().equals(r.owner) || p.hasPermission("deathchest.bypass")) return;
        e.setCancelled(true);
        plugin.msg(p, "not-owner");
    }

    // ---------------------------------- vanish when the chest is emptied

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        scheduleEmptyCheck(e.getView().getTopInventory());
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        scheduleEmptyCheck(e.getView().getTopInventory());
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        scheduleEmptyCheck(e.getInventory());
    }

    private void scheduleEmptyCheck(Inventory inv) {
        if (manager.chestOf(inv) == null) return;
        Bukkit.getScheduler().runTask(plugin, () -> checkEmpty(inv));
    }

    private void checkEmpty(Inventory inv) {
        DeathChest r = manager.chestOf(inv);
        if (r == null) return;
        for (ItemStack i : inv.getContents()) {
            if (i != null && !i.getType().isAir()) return;
        }
        List<HumanEntity> viewers = new ArrayList<>(inv.getViewers());
        manager.remove(r, true);
        Player owner = Bukkit.getPlayer(r.owner);
        if (owner != null) plugin.msg(owner, "chest-emptied");
        for (HumanEntity v : viewers) {
            if (v instanceof Player vp && !vp.getUniqueId().equals(r.owner)) {
                plugin.msg(vp, "chest-emptied");
            }
        }
    }
}
