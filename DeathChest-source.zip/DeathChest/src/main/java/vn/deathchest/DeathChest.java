package vn.deathchest;

import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.TextDisplay;

import java.util.UUID;

/** Một rương tử vong đang tồn tại (1 hoặc 2 block nếu là rương đôi). */
public final class DeathChest {
    public final UUID id;
    public final UUID owner;
    public final String ownerName;
    public final UUID worldId;
    public final int x, y, z;
    public final boolean isDouble;
    public final int x2, y2, z2;
    public final long createdAt;

    public int remaining;      // giây còn lại
    public boolean backUsed;   // đã dùng /back cho rương này chưa

    // runtime
    public TextDisplay display;
    public String lastText = "";

    public DeathChest(UUID id, UUID owner, String ownerName, UUID worldId,
                      int x, int y, int z,
                      boolean isDouble, int x2, int y2, int z2,
                      int remaining, boolean backUsed, long createdAt) {
        this.id = id;
        this.owner = owner;
        this.ownerName = ownerName;
        this.worldId = worldId;
        this.x = x;
        this.y = y;
        this.z = z;
        this.isDouble = isDouble;
        this.x2 = x2;
        this.y2 = y2;
        this.z2 = z2;
        this.remaining = remaining;
        this.backUsed = backUsed;
        this.createdAt = createdAt;
    }

    public Block primary(World w) {
        return w.getBlockAt(x, y, z);
    }

    public Block secondary(World w) {
        return isDouble ? w.getBlockAt(x2, y2, z2) : null;
    }

    public String key1() {
        return ChestManager.key(worldId, x, y, z);
    }

    public String key2() {
        return isDouble ? ChestManager.key(worldId, x2, y2, z2) : null;
    }
}
