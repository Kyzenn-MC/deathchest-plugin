package vn.deathchest;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.JoinConfiguration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.Chest;
import org.bukkit.block.TileState;
import org.bukkit.block.data.Waterlogged;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Display;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.block.DoubleChest;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public final class ChestManager {

    private static final BlockFace[] HORIZONTAL =
            {BlockFace.NORTH, BlockFace.EAST, BlockFace.SOUTH, BlockFace.WEST};

    private final DeathChestPlugin plugin;
    private final File file;
    private final MiniMessage mm = MiniMessage.miniMessage();

    private final Map<UUID, DeathChest> chests = new LinkedHashMap<>();
    private final Map<String, DeathChest> byBlock = new HashMap<>();

    private BukkitTask task;
    private int saveCounter = 0;

    public ChestManager(DeathChestPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "data.yml");
    }

    // ------------------------------------------------------------------ keys

    public static String key(UUID world, int x, int y, int z) {
        return world + ":" + x + ":" + y + ":" + z;
    }

    public static String key(Block b) {
        return key(b.getWorld().getUID(), b.getX(), b.getY(), b.getZ());
    }

    // ------------------------------------------------------------ lifecycle

    public void start() {
        load();
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, 20L);
    }

    public void stop() {
        if (task != null) task.cancel();
        save();
        for (DeathChest r : chests.values()) removeDisplay(r);
    }

    // -------------------------------------------------------------- queries

    public DeathChest at(Block b) {
        return byBlock.get(key(b));
    }

    public boolean isChest(Block b) {
        return byBlock.containsKey(key(b));
    }

    public DeathChest get(UUID id) {
        return chests.get(id);
    }

    public Collection<DeathChest> all() {
        return chests.values();
    }

    /** Tìm rương tử vong từ một Inventory (rương đơn hoặc rương đôi). */
    public DeathChest chestOf(Inventory inv) {
        if (inv == null) return null;
        InventoryHolder h = inv.getHolder(false);
        if (h instanceof DoubleChest dc) {
            InventoryHolder l = dc.getLeftSide(false);
            InventoryHolder r = dc.getRightSide(false);
            if (l instanceof Chest c) {
                DeathChest d = byBlock.get(key(c.getBlock()));
                if (d != null) return d;
            }
            if (r instanceof Chest c) {
                return byBlock.get(key(c.getBlock()));
            }
            return null;
        }
        if (h instanceof Chest c) {
            return byBlock.get(key(c.getBlock()));
        }
        return null;
    }

    /** Rương mới nhất của người chơi còn dùng được /back. */
    public DeathChest latestFor(UUID owner, boolean unusedOnly) {
        DeathChest best = null;
        for (DeathChest r : chests.values()) {
            if (!r.owner.equals(owner)) continue;
            if (r.remaining <= 0) continue;
            if (unusedOnly && r.backUsed) continue;
            if (best == null || r.createdAt > best.createdAt) best = r;
        }
        return best;
    }

    // ------------------------------------------------------------- creation

    /** Tạo rương tại đúng block chết. Trả về null nếu không tạo được (đồ được rơi ra đất). */
    public DeathChest create(Player owner, Location deathLoc, List<ItemStack> items) {
        World world = deathLoc.getWorld();
        FileConfiguration cfg = plugin.getConfig();

        Block base = deathLoc.getBlock();
        if (base.getY() < world.getMinHeight() || base.getY() > world.getMaxHeight() - 3) {
            // chết ngoài giới hạn thế giới (vd /kill trong void) -> dùng spawn
            base = world.getSpawnLocation().getBlock();
        }

        Block primary = findSpot(base);
        if (primary == null) {
            dropAll(deathLoc, items);
            return null;
        }

        // Cần rương đôi nếu > 27 stack
        Block secondary = null;
        BlockFace dir = null;
        if (items.size() > 27) {
            for (BlockFace f : HORIZONTAL) {
                Block b = primary.getRelative(f);
                if (valid(b)) {
                    secondary = b;
                    dir = f;
                    break;
                }
            }
        }

        boolean lava = isLava(primary) || isLava(primary.getRelative(BlockFace.UP));

        place(primary, secondary, dir);

        // Đổ đồ vào rương
        if (primary.getState(false) instanceof Chest chestState) {
            Inventory inv = chestState.getInventory();
            Map<Integer, ItemStack> left = inv.addItem(items.toArray(new ItemStack[0]));
            for (ItemStack i : left.values()) {
                world.dropItemNaturally(primary.getLocation().add(0.5, 1, 0.5), i);
            }
        } else {
            dropAll(deathLoc, items);
            return null;
        }

        DeathChest r = new DeathChest(
                UUID.randomUUID(), owner.getUniqueId(), owner.getName(), world.getUID(),
                primary.getX(), primary.getY(), primary.getZ(),
                secondary != null,
                secondary != null ? secondary.getX() : 0,
                secondary != null ? secondary.getY() : 0,
                secondary != null ? secondary.getZ() : 0,
                cfg.getInt("chest.lifetime-seconds", 600), false, System.currentTimeMillis());
        chests.put(r.id, r);
        byBlock.put(r.key1(), r);
        if (r.isDouble) byBlock.put(r.key2(), r);

        List<Block> blocks = new ArrayList<>();
        blocks.add(primary);
        if (secondary != null) blocks.add(secondary);

        if (lava && cfg.getBoolean("lava.enabled", true)) {
            buildLavaPocket(blocks);
        } else if (cfg.getBoolean("clear.enabled", true) && isEnclosed(blocks)) {
            clearArea(blocks);
        }

        updateDisplay(r, world);
        save();
        return r;
    }

    private void place(Block primary, Block secondary, BlockFace dir) {
        BlockFace facing = secondary == null ? BlockFace.SOUTH : ccw(dir);
        boolean pw = primary.getType() == Material.WATER;
        boolean sw = secondary != null && secondary.getType() == Material.WATER;

        org.bukkit.block.data.type.Chest d1 =
                (org.bukkit.block.data.type.Chest) Material.CHEST.createBlockData();
        d1.setFacing(facing);
        d1.setType(secondary == null
                ? org.bukkit.block.data.type.Chest.Type.SINGLE
                : org.bukkit.block.data.type.Chest.Type.RIGHT);
        d1.setWaterlogged(pw);

        if (secondary != null) {
            // secondary nằm ở primary + dir = cw(facing) => secondary là nửa LEFT
            org.bukkit.block.data.type.Chest d2 =
                    (org.bukkit.block.data.type.Chest) Material.CHEST.createBlockData();
            d2.setFacing(facing);
            d2.setType(org.bukkit.block.data.type.Chest.Type.LEFT);
            d2.setWaterlogged(sw);
            secondary.setBlockData(d2, false);
        }
        primary.setBlockData(d1, false);
    }

    private static BlockFace ccw(BlockFace f) {
        return switch (f) {
            case NORTH -> BlockFace.WEST;
            case WEST -> BlockFace.SOUTH;
            case SOUTH -> BlockFace.EAST;
            default -> BlockFace.NORTH; // EAST
        };
    }

    private void dropAll(Location loc, List<ItemStack> items) {
        for (ItemStack i : items) loc.getWorld().dropItemNaturally(loc, i);
    }

    /** Block hợp lệ để đặt rương (không ghi đè rương khác / block không thể phá / tile entity). */
    private boolean valid(Block b) {
        World w = b.getWorld();
        int y = b.getY();
        if (y < w.getMinHeight() || y > w.getMaxHeight() - 3) return false;
        if (isChest(b)) return false;
        if (b.getType().getHardness() < 0) return false;
        return !(b.getState(false) instanceof TileState);
    }

    /** Ưu tiên đúng block chết; chỉ khi bị chiếm (vd rương khác) mới tìm block gần nhất. */
    private Block findSpot(Block base) {
        if (valid(base)) return base;
        Block best = null;
        int bestDist = Integer.MAX_VALUE;
        for (int dx = -3; dx <= 3; dx++) {
            for (int dy = -3; dy <= 3; dy++) {
                for (int dz = -3; dz <= 3; dz++) {
                    int d = dx * dx + dy * dy + dz * dz;
                    if (d == 0 || d >= bestDist) continue;
                    Block b = base.getRelative(dx, dy, dz);
                    if (valid(b)) {
                        best = b;
                        bestDist = d;
                    }
                }
            }
        }
        return best;
    }

    private static boolean isLava(Block b) {
        return b.getType() == Material.LAVA;
    }

    // ------------------------------------------------- enclosed / clearing

    private boolean isEnclosed(List<Block> chestBlocks) {
        for (Block c : chestBlocks) {
            // block đặc phía trên khiến rương không mở được
            if (c.getRelative(BlockFace.UP).getType().isOccluding()) return true;
        }
        for (Block c : chestBlocks) {
            for (BlockFace f : HORIZONTAL) {
                Block n = c.getRelative(f);
                if (isChest(n)) continue;
                if (n.isPassable() && n.getRelative(BlockFace.UP).isPassable()) return false;
            }
        }
        return true;
    }

    private void clearArea(List<Block> chestBlocks) {
        FileConfiguration cfg = plugin.getConfig();
        int r = Math.max(0, cfg.getInt("clear.radius", 1));
        int h = Math.max(1, cfg.getInt("clear.height", 2));
        boolean drop = cfg.getBoolean("clear.drop-items", false);

        Set<Material> never = new HashSet<>();
        for (String s : cfg.getStringList("clear.never-break")) {
            Material m = Material.matchMaterial(s);
            if (m != null) never.add(m);
        }

        Set<Block> done = new HashSet<>();
        for (Block c : chestBlocks) {
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    for (int dy = 0; dy <= h; dy++) {
                        Block b = c.getRelative(dx, dy, dz);
                        if (!done.add(b)) continue;
                        if (isChest(b)) continue;
                        Material t = b.getType();
                        if (t.isAir() || b.isLiquid()) continue;
                        if (t.getHardness() < 0 || never.contains(t)) continue;
                        if (b.getState(false) instanceof TileState) continue;
                        if (drop) {
                            b.breakNaturally();
                        } else {
                            b.setType(Material.AIR, false);
                        }
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------- lava

    /**
     * Lấp toàn bộ lava quanh rương bằng block rắn, chỉ chừa: ô trên rương, 1 ô đứng
     * cạnh rương và ô đầu của ô đứng. Vì mọi lava lân cận đã bị lấp nên lava không
     * thể chảy vào chỗ trống.
     */
    private void buildLavaPocket(List<Block> chestBlocks) {
        FileConfiguration cfg = plugin.getConfig();
        Material fill = Material.matchMaterial(cfg.getString("lava.fill-material", "COBBLESTONE"));
        if (fill == null || !fill.isBlock() || fill.isAir()) fill = Material.COBBLESTONE;
        int r = Math.max(1, cfg.getInt("lava.radius", 2));

        Block first = chestBlocks.get(0);
        World w = first.getWorld();

        Set<Block> open = new HashSet<>();
        for (Block c : chestBlocks) open.add(c.getRelative(BlockFace.UP));

        Block stand = null;
        outer:
        for (Block c : chestBlocks) {
            for (BlockFace f : HORIZONTAL) {
                Block n = c.getRelative(f);
                if (isChest(n)) continue;
                stand = n;
                break outer;
            }
        }
        if (stand != null) {
            open.add(stand);
            open.add(stand.getRelative(BlockFace.UP));
        }

        int minX = Integer.MAX_VALUE, maxX = Integer.MIN_VALUE;
        int minZ = Integer.MAX_VALUE, maxZ = Integer.MIN_VALUE;
        for (Block c : chestBlocks) {
            minX = Math.min(minX, c.getX() - r);
            maxX = Math.max(maxX, c.getX() + r);
            minZ = Math.min(minZ, c.getZ() - r);
            maxZ = Math.max(maxZ, c.getZ() + r);
        }
        int minY = first.getY() - 1;
        int maxY = first.getY() + 3;

        for (int x = minX; x <= maxX; x++) {
            for (int y = minY; y <= maxY; y++) {
                if (y < w.getMinHeight() || y >= w.getMaxHeight()) continue;
                for (int z = minZ; z <= maxZ; z++) {
                    Block b = w.getBlockAt(x, y, z);
                    if (isChest(b)) continue;
                    Material t = b.getType();
                    if (open.contains(b)) {
                        boolean breakable = t.isSolid() && t.getHardness() >= 0
                                && !(b.getState(false) instanceof TileState);
                        if (t == Material.LAVA || breakable) b.setType(Material.AIR, false);
                        continue;
                    }
                    if (t == Material.LAVA) b.setType(fill, false);
                }
            }
        }

        // đảm bảo có nền đứng vững
        if (stand != null) {
            Block floor = stand.getRelative(BlockFace.DOWN);
            Material t = floor.getType();
            if (!t.isSolid() && t.getHardness() >= 0) floor.setType(fill, false);
        }
    }

    // ----------------------------------------------------- stand location

    public Location standLocation(DeathChest r) {
        World w = Bukkit.getWorld(r.worldId);
        if (w == null) return null;
        List<Block> cs = new ArrayList<>();
        cs.add(r.primary(w));
        if (r.isDouble) cs.add(r.secondary(w));

        for (Block c : cs) {
            for (BlockFace f : HORIZONTAL) {
                Block n = c.getRelative(f);
                if (isChest(n)) continue;
                if (safeStand(n)) {
                    Location l = n.getLocation().add(0.5, 0, 0.5);
                    Location look = c.getLocation().add(0.5, 0.5, 0.5);
                    l.setDirection(look.toVector().subtract(l.toVector()));
                    return l;
                }
            }
        }
        return cs.get(0).getRelative(BlockFace.UP).getLocation().add(0.5, 0, 0.5);
    }

    private boolean safeStand(Block n) {
        Block up = n.getRelative(BlockFace.UP);
        Block down = n.getRelative(BlockFace.DOWN);
        return n.isPassable() && up.isPassable()
                && !isLava(n) && !isLava(up) && !isLava(down)
                && down.getType().isSolid()
                && down.getType() != Material.MAGMA_BLOCK;
    }

    // ------------------------------------------------------------- removal

    public void remove(DeathChest r, boolean breakBlocks) {
        chests.remove(r.id);
        byBlock.remove(r.key1());
        if (r.isDouble) byBlock.remove(r.key2());
        removeDisplay(r);

        World w = Bukkit.getWorld(r.worldId);
        if (w != null && breakBlocks) {
            clearChestBlock(r.primary(w));
            if (r.isDouble) clearChestBlock(r.secondary(w));
        }
        save();
    }

    private void clearChestBlock(Block b) {
        if (b.getType() != Material.CHEST) return;
        boolean water = b.getBlockData() instanceof Waterlogged wl && wl.isWaterlogged();
        b.setType(water ? Material.WATER : Material.AIR, false);
    }

    private void expire(DeathChest r, World w) {
        if (plugin.getConfig().getBoolean("chest.drop-items-on-expire", false)) {
            Block p = r.primary(w);
            if (p.getState(false) instanceof Chest c) {
                Inventory inv = c.getInventory();
                Location at = p.getLocation().add(0.5, 1, 0.5);
                for (ItemStack i : inv.getContents()) {
                    if (i != null && !i.getType().isAir()) w.dropItemNaturally(at, i);
                }
                inv.clear();
            }
        }
        remove(r, true);
        Player o = Bukkit.getPlayer(r.owner);
        if (o != null) plugin.msg(o, "chest-expired");
    }

    // ---------------------------------------------------------------- tick

    private void tick() {
        for (DeathChest r : new ArrayList<>(chests.values())) {
            World w = Bukkit.getWorld(r.worldId);
            if (w == null) continue;
            if (r.remaining > 0) r.remaining--;
            if (!w.isChunkLoaded(r.x >> 4, r.z >> 4)) continue;
            if (r.isDouble && !w.isChunkLoaded(r.x2 >> 4, r.z2 >> 4)) continue;

            if (r.primary(w).getType() != Material.CHEST) {
                remove(r, false); // bị xóa bằng cách khác (WorldEdit, v.v.)
                continue;
            }
            if (r.remaining <= 0) {
                expire(r, w);
                continue;
            }
            updateDisplay(r, w);
        }
        if (++saveCounter >= 30) {
            saveCounter = 0;
            save();
        }
    }

    // ------------------------------------------------------------ hologram

    private void updateDisplay(DeathChest r, World w) {
        if (!plugin.getConfig().getBoolean("hologram.enabled", true)) {
            removeDisplay(r);
            return;
        }
        String time = formatTime(r.remaining);
        if (r.display == null || !r.display.isValid()) {
            double cx = r.x + 0.5;
            double cz = r.z + 0.5;
            if (r.isDouble) {
                cx = (r.x + r.x2) / 2.0 + 0.5;
                cz = (r.z + r.z2) / 2.0 + 0.5;
            }
            double cy = r.y + plugin.getConfig().getDouble("hologram.height-offset", 1.4);
            Location loc = new Location(w, cx, cy, cz);
            r.display = w.spawn(loc, TextDisplay.class, td -> {
                td.setBillboard(Display.Billboard.CENTER);
                td.setPersistent(false);
                td.setInvulnerable(true);
                td.setBackgroundColor(Color.fromARGB(110, 0, 0, 0));
            });
            r.lastText = "";
        }
        if (!time.equals(r.lastText)) {
            r.lastText = time;
            r.display.text(buildText(r, time));
        }
    }

    private Component buildText(DeathChest r, String time) {
        List<Component> lines = new ArrayList<>();
        for (String l : plugin.getConfig().getStringList("hologram.lines")) {
            lines.add(mm.deserialize(l,
                    Placeholder.unparsed("player", r.ownerName),
                    Placeholder.unparsed("time", time)));
        }
        return Component.join(JoinConfiguration.newlines(), lines);
    }

    private void removeDisplay(DeathChest r) {
        if (r.display != null) {
            if (r.display.isValid()) r.display.remove();
            r.display = null;
        }
    }

    /** Buộc hologram cập nhật lại sau khi /deathchest reload. */
    public void refreshAllDisplays() {
        for (DeathChest r : chests.values()) {
            removeDisplay(r);
            r.lastText = "";
        }
    }

    public static String formatTime(int seconds) {
        int s = Math.max(0, seconds);
        int h = s / 3600;
        int m = (s % 3600) / 60;
        int sec = s % 60;
        if (h > 0) return String.format("%d:%02d:%02d", h, m, sec);
        return String.format("%02d:%02d", m, sec);
    }

    // --------------------------------------------------------- persistence

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (DeathChest r : chests.values()) {
            String p = "chests." + r.id;
            y.set(p + ".owner", r.owner.toString());
            y.set(p + ".ownerName", r.ownerName);
            y.set(p + ".world", r.worldId.toString());
            y.set(p + ".x", r.x);
            y.set(p + ".y", r.y);
            y.set(p + ".z", r.z);
            y.set(p + ".double", r.isDouble);
            y.set(p + ".x2", r.x2);
            y.set(p + ".y2", r.y2);
            y.set(p + ".z2", r.z2);
            y.set(p + ".remaining", r.remaining);
            y.set(p + ".backUsed", r.backUsed);
            y.set(p + ".createdAt", r.createdAt);
        }
        try {
            file.getParentFile().mkdirs();
            y.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Không lưu được data.yml: " + e.getMessage());
        }
    }

    private void load() {
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = y.getConfigurationSection("chests");
        if (root == null) return;
        for (String id : root.getKeys(false)) {
            ConfigurationSection c = root.getConfigurationSection(id);
            if (c == null) continue;
            try {
                DeathChest r = new DeathChest(
                        UUID.fromString(id),
                        UUID.fromString(c.getString("owner", "")),
                        c.getString("ownerName", "?"),
                        UUID.fromString(c.getString("world", "")),
                        c.getInt("x"), c.getInt("y"), c.getInt("z"),
                        c.getBoolean("double"),
                        c.getInt("x2"), c.getInt("y2"), c.getInt("z2"),
                        c.getInt("remaining"),
                        c.getBoolean("backUsed"),
                        c.getLong("createdAt"));
                chests.put(r.id, r);
                byBlock.put(r.key1(), r);
                if (r.isDouble) byBlock.put(r.key2(), r);
            } catch (Exception ex) {
                plugin.getLogger().warning("Bỏ qua bản ghi lỗi " + id + ": " + ex.getMessage());
            }
        }
        plugin.getLogger().info("Đã tải " + chests.size() + " rương tử vong.");
    }
}
