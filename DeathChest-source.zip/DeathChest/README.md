# DeathChest (Paper 26.3, Java 25)

## Build
    gradle build        # hoặc ./gradlew build nếu bạn có wrapper
File jar nằm ở `build/libs/DeathChest-1.0.0.jar` -> bỏ vào thư mục `plugins/`.

## Lưu ý
- Nếu server có Essentials (/back), hãy tắt lệnh back của Essentials hoặc dùng `/deathchest:back`.
- Chỉnh thời gian rương ở `plugins/DeathChest/config.yml` -> `chest.lifetime-seconds`, rồi `/deathchest reload`.
